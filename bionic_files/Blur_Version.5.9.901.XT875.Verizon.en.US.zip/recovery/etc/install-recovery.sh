#!/system/bin/sh
if ! applypatch -c MTD:recovery:2048:5bd86bbf5ddae14c6b0fd3c8b4c13f1b59e7afb0; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:8388608:99cc2fa5cdcd48c741d08172ed0f359b936f551b MTD:recovery 11c9c15ec57746609037e9def14086f7a388d1b4 9437184 99cc2fa5cdcd48c741d08172ed0f359b936f551b:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
