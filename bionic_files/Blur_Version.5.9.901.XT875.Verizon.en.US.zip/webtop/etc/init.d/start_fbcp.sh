#! /bin/sh

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
DBUSFILE=/home/adas/tmp/fbcp_dbus
export LD_LIBRARY_PATH=/usr/lib:/usr/local/lib

. /lib/lsb/init-functions

log_action_msg "Will now start Firebox Computing Platform"

# cleanse /tmp of adas owned files
##################################
CWD=`pwd`
cd /data/tmp
ls -l > /home/adas/tmp.list
rm -f /home/adas/remove.list
touch /home/adas/remove.list
filelist=`ls -l | awk '{ if ( $3 ~ /adas/ ) { print $9 } }'`
for f in $filelist
do
        echo "removing $f from /tmp" >> /home/adas/remove.list
        rm -fr $f
done
cd $CWD

# now cleanse adas "private" tmp
################################
if [ -d /home/adas/tmp ]
then
	rm -fr /home/adas/tmp/*
else
	mkdir -p /home/adas/tmp
fi

# now get down to business of starting fbcp...
##############################################
dbus-launch > $DBUSFILE
chown root.adas $DBUSFILE
chmod 640 $DBUSFILE

# start firebox procs
sfalv -p "resourcemanager -d -v -s Android"
sfalv -i "intent -d"
sfalv -i "webtop-restart -d --nodaemon"

