#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LD_LIBRARY_PATH=/usr/lib:/usr/local/lib

NAME=startWebtop
DESC="OSH Webtop Client Apps"

. /lib/lsb/init-functions

. /etc/environment
export PATH
export LANG
export DISPLAY
export LD_LIBRARY_PATH
export USER=adas
export HOME=/home/$USER
export `fbcp_dsba`

create_lock_or_exit () {
  while true; do
        if mkdir "/tmp/webtop_restart.lock.d"; then
           break;
        fi
        logger -i "startX.sh: restart in progress exiting"
        exit 1
  done
}

remove_lock () {
  rmdir "/tmp/webtop_restart.lock.d"
}

for i in `seq 1 2`
do
    if ps aux | grep /usr/bin/X | grep -v grep > /dev/null
    then
        logger -i "startX.sh X is running"
        break
    else
        logger -i "startX.sh X is not running Try again"
        sleep 1
    fi
done

if [ $i -eq 2 ]
then
    logger -i "startX.sh: X crashed Try restart"
    /etc/init.d/webtop-restart.sh
    exit 1
fi

create_lock_or_exit
if  ps aux | grep metacity | grep -v grep > /dev/null
then
   logger -i "startX.sh metacity already running, ignore"
   remove_lock
   exit 1
else
   sudo -u adas -i /usr/local/bin/start-oshwt-1.sh &
fi
remove_lock

echo "START"
