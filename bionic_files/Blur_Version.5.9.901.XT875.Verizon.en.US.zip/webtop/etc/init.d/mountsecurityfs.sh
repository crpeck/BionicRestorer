#! /bin/sh
### BEGIN INIT INFO
# Provides:          mount securityfs
# Required-Start:    
# Required-Stop:
# Should-Start:      
# Default-Start:     
# Default-Stop:
# Short-Description: mount securityfs for tomoyo
# Description:       
#                    
### END INIT INFO

# . /lib/init/vars.sh
. /lib/lsb/init-functions

is_securityfs_mounted() {
        grep -q securityfs /proc/filesystems && grep -q securityfs /proc/mounts
        return $?
}

mount_securityfs() {
        if grep -q securityfs /proc/filesystems ; then
                echo "Mounting seurityfs on /sys/kernel/security" 
                mount -t securityfs securityfs /sys/kernel/security
                return $?
        fi
        return 0
}

if ! is_securityfs_mounted ; then
        mount_securityfs
fi

if [ ! -f /sbin/tomoyo-start ] ; then
        ln -s /bin/true /sbin/tomoyo-start
fi

/sbin/tomoyo-start

exit 0

