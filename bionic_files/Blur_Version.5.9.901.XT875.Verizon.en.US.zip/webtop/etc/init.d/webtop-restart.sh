#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LD_LIBRARY_PATH=/usr/lib:/usr/local/lib

RESTART_FILE=/tmp/restart_in_progress
touch $RESTART_FILE

logger -i "/etc/init.d/webtop-restart.sh about to start killing processes..."

APPS="startx
      xinit
      xnull
      aiw
      evbridge
      /usr/bin/lxsession
      webdaemon
      docking_manager
      webtop-panel
      webtop-wallpaper
      awn-autostart
      awn
      avant-window-navigator
      xscreensaver
      gvfs-gdu-volume-monitor
      window_switcher
      metacity
      /usr/bin/X"

for APP in $APPS
do
    kill `pgrep -f $APP 2>/dev/null`
done

#/etc/init.d/startXServer.sh webtop
#nvrm=`pgrep -f nvrm_daemon -u root`

#if [ x"$nvrm" = x ]
#then
#    logger -i "/etc/init.d/webtop-restart.sh Not starting X server since nvrm_daemon is NOT running..."
#else
    logger -i "/etc/init.d/webtop-restart.sh about to start X Server..."
    /etc/init.d/startXServer.sh
#fi

rm -f $RESTART_FILE

