#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LD_LIBRARY_PATH=/usr/lib:/usr/local/lib

SHUTDOWN_FILE=/tmp/shutdown_in_progress
touch $SHUTDOWN_FILE

logger -i "/etc/init.d/webtop-restart.sh about to start killing processes..."

APPS="startx
      xinit
      xnull
      aiw
      /usr/bin/X
      evbridge
      /usr/bin/lxsession
      webdaemon
      docking_manager
      webtop-panel
      webtop-wallpaper
      awn-autostart
      awn
      avant-window-navigator
      xscreensaver
      gvfs-gdu-volume-monitor"

for APP in $APPS
do
    kill `pgrep -f $APP 2>/dev/null`
done

rm -f $SHUTDOWN_FILE

