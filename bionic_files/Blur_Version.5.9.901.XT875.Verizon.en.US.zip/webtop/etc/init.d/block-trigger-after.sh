sleep 1
rm /tmp/vdt
