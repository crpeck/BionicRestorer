#! /bin/sh
### BEGIN INIT INFO
# Provides:          syslog-restart
# Required-Start:    
# Required-Stop:
# Default-Start:     5
# Default-Stop:
# Short-Description: started by root user at login
### END INIT INFO

. /etc/environment
. /lib/lsb/init-functions

log_action_msg "Will now start Syslog-Restart Root Helper"

if [ ! -p /tmp/syslog_restart ] 
then
    mkfifo /tmp/syslog_restart
fi
chmod 666 /tmp/syslog_restart

sfalv "syslog-restart -d"
os_ret=$?
if [ $os_ret -ne 0 ]
then
	log_action_msg "sfalv could not start syslog-restart..$os_ret"
fi

