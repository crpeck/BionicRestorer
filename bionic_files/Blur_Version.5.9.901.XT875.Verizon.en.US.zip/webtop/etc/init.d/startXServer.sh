#!/bin/sh
#
# startX.sh
#
# This script starts the X server
#
# In order to enable or disable this script just change the execution
# bits.
#
# By default this script does nothing.

PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
NAME=startX
DESC="OSH X Server"

. /lib/lsb/init-functions


#umask 002

log_begin_msg "Starting $DESC: $NAME"

rm -f /tmp/serverauth.*
rm -f /tmp/.X0-lock
rm -fr /tmp/.X11-unix
rm -fr /tmp/.ICE-unix

if [ ! -e /home/adas/.tag_master_reset_ls ]; then
    /usr/local/sbin/update-language.pl "en_US.UTF-8"
    echo 1 > /home/adas/.tag_master_reset_ls
fi

. /etc/environment
export PATH
export LANG
export DISPLAY
export LD_LIBRARY_PATH
export USER=adas
export HOME=/home/$USER

# new way of starting
if [ X$1 = Xwebtop ]
then
    if [ -e /usr/lib/xorg/modules/drivers/tegra_drv.so ];
    then
        sudo -u adas -i /usr/bin/startx -- -nolisten tcp -layout HDMI vt2 &
    else
        sudo -u adas -i /usr/bin/startx -- -nolisten tcp vt2 &
    fi
else
    if [ -e /usr/lib/xorg/modules/drivers/tegra_drv.so ];
    then
        sudo -u adas -i /usr/bin/startx /usr/local/bin/xnull -- -nolisten tcp -layout HDMI vt2 &
    else
        sudo -u adas -i /usr/bin/startx /usr/local/bin/xnull -- -nolisten tcp vt2 &
    fi
fi

