touch /tmp/vdt
chmod 777 /tmp/vdt
